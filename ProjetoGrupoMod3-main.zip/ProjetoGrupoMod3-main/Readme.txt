Criando o projeto:
Na pasta iremos dar um npx create-react-app nomeDoProjeto dentro do terminal do VSCode
Depois um: npm install json-server react-icons react-router-dom uui

Bibliotecas para baixar após ter feito o clone:
- npm install json-server:  (que utilizaremos para fazer o resgate de dados na api fake que servirá como um back end
- npm install react-icons: é um pacote de ícones do react
- npm install react-router-dom:
- npm install uuid: biblioteca que cria id para gente a cada dado inserido.
- 

2º Na pasta src só ficaram os arquivos App.js, index.css e index.js


--------------------------------- ANATAÇÕES IMPORTANTES ------------------------------------

Pontos a acertar:

- Aumentar os tópicos dos formulários de Compradores e Vendedores;
- Posicionar os cards das pags. Imoveis, Clientes e Funcionários um ao lado do outro;
